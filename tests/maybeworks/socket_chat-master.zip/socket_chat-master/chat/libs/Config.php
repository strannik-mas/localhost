<?php
/**
 * Created by PhpStorm.
 * User: daniil
 * Date: 25.10.16
 * Time: 16:50
 */

namespace chat\libs;

use chat\libs\base\ConfigBase;

/**
 * Class Config
 * @package chat\libs
 */
class Config extends ConfigBase
{
}
